$(document).ready(function(){

  // Add Class postion-relaitve in Navigation
  if($('ul.header__menu').parent('li')) {
    $('ul.header__menu').parent('li').children('a').addClass('position-relative');
  }

  //Toggle BUtton
  $('.navbar-toggler').click(function(){
    $('.header').toggleClass('header--active');
  });

  // Popup Video
  $('.body-kit__right-box').click(function() {
		$('.video-container').show();
	});
	$('.close-video').click(function() {
		$('.video-container').hide();
	});
});